import java.util.HashSet;
import java.util.LinkedList;

/**
 * Forma Normal Konjuntiboan (CNF) dauden formula boolearrak irudikatzeko Java klasea
 */
public class CNFFormula implements Comparable<CNFFormula>{
	private LinkedList<Klausula> klausulaZerrenda;
	private Klausula klausulaTxikiena;
	private LinkedList<KlausulaLiterala> literalenEsleipenak;
	private int [] baiLiteralKop;
	private int [] ezLiteralKop;
	private HashSet<KlausulaLiterala> literalPuruak; 
	
	/**
	 * Metodo Eraikitzailea
	 */
	public CNFFormula(){
		this.klausulaZerrenda = new LinkedList<Klausula>();
		this.literalenEsleipenak = new LinkedList<KlausulaLiterala>();
		this.literalPuruak = new HashSet<KlausulaLiterala>();
		this.klausulaTxikiena = null;
		this.baiLiteralKop = null;
		this.ezLiteralKop = null;
	}
	
	/**
	 * Bestelako metodoak
	 */
	
	public boolean hutsaDa(){
		return (klausulaZerrenda.size()==0);
	}
	
    public void klausulaBerriaGehitu(Klausula klausula) {
    	klausulaZerrenda.add(klausula);
    }
    
    public void literalPuruaGehitu(KlausulaLiterala literalPurua){
    	literalPuruak.add(literalPurua);
    }

    public LinkedList<Klausula> getKlausulaZerrenda(){
		return klausulaZerrenda;
	}
    
    /**
     * Getter eta Setterrak
     */
    
	public LinkedList<KlausulaLiterala> getLiteralenEsleipenak() {
		return literalenEsleipenak;
	}

	public void setLiteralenEsleipenak(LinkedList<KlausulaLiterala> literalenEsleipenak) {
		this.literalenEsleipenak = literalenEsleipenak;
	}

	public Klausula getKlausulaTxikiena() {
		return klausulaTxikiena;
	}

	public void setKlausulaTxikiena(Klausula klausulaTxikiena) {
		this.klausulaTxikiena = klausulaTxikiena;
	}

	public int [] getBaiLiteralKop() {
		return baiLiteralKop;
	}

	public void setBaiLiteralKop(int [] baiLiteralKop) {
		this.baiLiteralKop = baiLiteralKop;
	}

	public int [] getEzLiteralKop() {
		return ezLiteralKop;
	}

	public void setEzLiteralKop(int [] ezLiteralKop) {
		this.ezLiteralKop = ezLiteralKop;
	}

	public HashSet<KlausulaLiterala> getLiteralPuruak() {
		return literalPuruak;
	}

	public void setLiteralPuruak(HashSet<KlausulaLiterala> literalPuruak) {
		this.literalPuruak = literalPuruak;
	}
	
	/**
	 * Bi formulen konparazioa zertan oinarritzen den adierazten duen metodoa (ordenazioa gauzatzeko).
	 * Formula bat beste batekin konparatuta txikiagoa izango da baldin eta klausula txikiagoak baditu (gutxienez bat).
	 * Adibidez: F1 = { (a v b v -c), (-c v -a), (-b v a) }
	 * 			 F2 = { (a v -b v c v d v e), (-a) }
	 * 		--> F2 formula F1 baino txikiagoa da.
	 */
	public int compareTo(CNFFormula formula){
		if(this.klausulaTxikiena.literalKopurua()>formula.klausulaTxikiena.literalKopurua()){
			return 1;
		}else if (this.klausulaTxikiena.literalKopurua()==formula.klausulaTxikiena.literalKopurua()){
			return 0;
		}else{
			return -1;
		}
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		for(Klausula k : klausulaZerrenda){
			sb.append(k.toString() + "y ");
		}
		if(sb.length()>3)sb.replace(sb.length()-3, sb.length()-1, "}");
		else sb.append("}");
		return sb.toString();
	}
}
