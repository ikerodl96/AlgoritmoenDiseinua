import java.io.File;
import java.util.LinkedList;


public class Frogak {
	final static File folder = new File("UF-BAI");
	

	
	public static void main(String[] args) {
		Kronometroa k = new Kronometroa();
		for (final File fileEntry : folder.listFiles()) {
            String path = folder + "/" + fileEntry.getName(); //"Fitxategia/zfrb30-15-1.cnf";
            System.out.println(path);
            SAT sat = new SAT();
    		sat.formulaEraiki(path);
    		k.start();
    		LinkedList<KlausulaLiterala> emaitza = sat.formulaBetearazi("emaitza");
    		k.stop();
    		System.out.println("SAT?: "+ (emaitza!=null));
    		System.out.println("_________________________________________________");
    		System.gc();
		}
//		SAT sat = new SAT();
//		sat.formulaEraiki("Fitxategia/uf20-0999.cnf");
//		LinkedList<KlausulaLiterala> emaitza = sat.formulaBetearazi("emaitza");
//		System.out.println(emaitza!=null);
	}
	
}
