import java.util.HashSet;
/**
 * CNF formula bateko klausulak irudikatzeko Java klasea
 */

public class Klausula {
	private HashSet<KlausulaLiterala> literalZerrenda;
	
	/**
	 * Metodo eraikitzailea
	 */
	public Klausula(){
		this.literalZerrenda =  new HashSet<KlausulaLiterala>();
	}
	
	
	/**
	 * Bestelako Metodoak
	 */
	
	public boolean hutsaDa(){
		return (literalZerrenda.size()==0);
	}
	
	public void literalaGehitu(KlausulaLiterala literala){
		literalZerrenda.add(literala);
	}
	
	/**
	 * Klausularen barneko edozein literal itzultzen duen metodoa (ez da lehenengoa izan behar)
	 */
	public KlausulaLiterala getLiteralBat(){
		return literalZerrenda.iterator().next();
	}
	
	public int literalKopurua(){
    	return literalZerrenda.size();
    }
	
	/**
	 * Klausularen barnean parametroz pasatutako literala dagoen ala ez adierazten duen metodoa
	 * Denbora konstantean O(1) exekutatzen da.
	 */
	public boolean klausulaLiteralaDago(KlausulaLiterala klausulaLiterala){
		return literalZerrenda.contains(klausulaLiterala);
	}
	
	/**
	 * Klausulatik parametroz pasatutako literala ezabatzen duen metodoa (literala klausularen barnean egotekotan)
	 * Denbora konstantean O(1) exekutatzen da.
	 */
	public void klausulaLiteralaEzabatu(KlausulaLiterala klausulaLiterala){
		literalZerrenda.remove(klausulaLiterala);
	}
    
	/**
	 * Klausula baten kopia egiten duen metodoa
	 */
	public Klausula kopia(){
		Klausula klausula = new Klausula();
		klausula.setLiteralZerrenda(new HashSet<KlausulaLiterala>(this.getKlausularenLiteralZerrenda()));
		return klausula;
	}
	
	/**
	 * Getter eta Setterrak
	 */
	
    public HashSet<KlausulaLiterala> getKlausularenLiteralZerrenda(){
    	return literalZerrenda;
    }

	public void setLiteralZerrenda(HashSet<KlausulaLiterala> literalZerrenda) {
		this.literalZerrenda = literalZerrenda;
	}
	

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("(");
		for(KlausulaLiterala kl : literalZerrenda){
			sb.append(kl.toString() + " v ");
		}
		if(sb.length()>3)sb.replace(sb.length()-3, sb.length()-1, ")");
		else sb.append(")");
		//sb.append(")");
		return sb.toString();
	}
	
}
