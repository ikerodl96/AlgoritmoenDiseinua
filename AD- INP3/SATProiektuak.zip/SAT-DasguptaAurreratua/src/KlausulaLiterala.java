/**
 * CNF formula bateko klausulen literalak irudikatzeko Java klasea
 */
public class KlausulaLiterala {
	private int literalZenbakia;
	private boolean zeinua; /* - == NOT == FALSE */
	
	/**
	 * Metodo Eraikitzailea
	 * @param aldagaia
	 * @param zeinua
	 */
	public KlausulaLiterala(int aldagaia, boolean zeinua) {
		this.literalZenbakia = aldagaia;
		this.zeinua = zeinua;
	}
	
	/**
	 * Getter eta Setterrak
	 */

	public int getLiteralZenbakia() {
		return literalZenbakia;
	}


	public boolean getZeinua() {
		return zeinua;
	}

	
	/**
	 * HashSet erabiltzeko behar diren bi metodoak: hashCode() eta equals()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + literalZenbakia;
		result = prime * result + (zeinua ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		KlausulaLiterala other = (KlausulaLiterala) obj;
		if (literalZenbakia != other.literalZenbakia)
			return false;
		if (zeinua != other.zeinua)
			return false;
		return true;
	}

	
	@Override
	public String toString() {
		if(zeinua){
			return "+" + literalZenbakia;
		}else{
			return "-" + literalZenbakia;
		}
	}

	public void setZeinua(boolean zeinua) {
		this.zeinua = zeinua;
	}  
}
