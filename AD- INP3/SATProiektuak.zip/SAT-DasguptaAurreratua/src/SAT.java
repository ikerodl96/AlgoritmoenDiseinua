import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 * Betegarritasun edo SAT problema ebazten duen Java klasea
 */
public class SAT {
	private CNFFormula formula;
	private int klausulaKopurua;
	private int literalKopurua;
	private long adabegiKop;
	
	/**
	 * Formulak fitxategietatik irakurtzen dituen metodoa
	 * @param fitxategiIzena Irakurriko den fitxategiaren izena
	 * @return 0 irakurketa ondo gauzatu bada eta (-1) bestela
	 */
	public int formulaEraiki(String fitxategiIzena){
		formula =  new CNFFormula();
		/* Literal bakoitzaren agerpenak zenbatzeko (literala eta bere ukapena) bektoreak */
		int [] baiLiteralKop;
		int [] ezLiteralKop;
		try {
			Scanner s = new Scanner(new File(fitxategiIzena));
			/* Hasierako 5 lerroak utzi (c) */
			for(int i=1; i<=5; i++) s.nextLine();
			/* 6 lerroan: p cnf NV NC */
			s.next(); // p 
			s.next(); // cnf
			literalKopurua = s.nextInt();
			/* Zenbaki osoko bektoreen balio lehenetsia -> 0 */
			baiLiteralKop =  new int [literalKopurua];
			ezLiteralKop = new int [literalKopurua];
			klausulaKopurua = s.nextInt();
			/* Formula osatzen duten klausulen irakurketa */
			for(int i=1; i<=klausulaKopurua; i++){
				Klausula klausulaBerria = new Klausula();
				int klausulaLiterala = s.nextInt();
				while(klausulaLiterala!=0){
					if(klausulaLiterala>0){
						klausulaBerria.literalaGehitu(new KlausulaLiterala(klausulaLiterala, true));
						baiLiteralKop[klausulaLiterala-1]++;
					}else{
						klausulaBerria.literalaGehitu(new KlausulaLiterala(klausulaLiterala*(-1), false));
						ezLiteralKop[(klausulaLiterala*(-1))-1]++;
					}
					klausulaLiterala = s.nextInt();
				}
				/* Formularen klausula txikiena harrapatzeko */
				if(formula.getKlausulaTxikiena()==null || formula.getKlausulaTxikiena().literalKopurua()>klausulaBerria.literalKopurua()){
					formula.setKlausulaTxikiena(klausulaBerria);
				}
				formula.klausulaBerriaGehitu(klausulaBerria);
			}
			formula.setBaiLiteralKop(baiLiteralKop);
			formula.setEzLiteralKop(ezLiteralKop);
			/* Hasierako literal puruak aurkitu eta ezabatu */
			for(int literala=0; literala<literalKopurua; literala++){
				if(baiLiteralKop[literala]==0){
					formula.literalPuruaGehitu(new KlausulaLiterala(literala+1, false));
				}else if(ezLiteralKop[literala]==0){
					formula.literalPuruaGehitu(new KlausulaLiterala(literala+1, true));
				}
			}
			s.close();
			return 0;
		} catch (Exception e) {
			System.out.println("Arazoa egon da '"+ fitxategiIzena +"' fitxategiaren irakurketarekin");
			System.out.println(e.getMessage());
			e.printStackTrace();
			return (-1);
		}
	}
	
	/**
	 * CNF formula bat SAT edo UNSAT den erabakitzen duen metodoa
	 * SAT izatekotan, literalei egin behar zaien esleipenak zerrenda batean itzuliko ditu
	 * UNSAT izatekotan, null balioa itzuliko du
	 */
	public LinkedList<KlausulaLiterala> formulaBetearazi(String outFitxategiIzena){
		/* Backtrack */
		LinkedList<KlausulaLiterala> esleipenak = backtrack();
		emaitzaFitxategianIdatzi(outFitxategiIzena, esleipenak);
		System.out.println("AdabegiKop: "+adabegiKop);
		return esleipenak;
	}

	/**
	 * Backtracking metodoa SAT problema ebazteko (Dasgupta liburuan agertzen den eskema bera)
	 */
	private LinkedList<KlausulaLiterala> backtrack(){
		/* Esplorazio zuhaitzaren erpinak zenbatzeko aldagaia */
		adabegiKop = 0; 
		/* Azpiformulak (jatorrizko formularen "azpiproblemak") dituen meta */
		PriorityQueue<CNFFormula> azpiformulak = new PriorityQueue<CNFFormula>();
		azpiformulak.add(formula);
		while (!azpiformulak.isEmpty()){
			/* Formula "txikiena" atera (formula guztien artetik klausula txikiena duena) */
			CNFFormula formula = azpiformulak.poll();
			LinkedList<CNFFormula> azpiformulaBerriak = hedatu(formula);
			adabegiKop = adabegiKop + azpiformulaBerriak.size();
			for(CNFFormula azpiformula : azpiformulaBerriak){
				if(azpiformula.hutsaDa()){
					/* Bilaketa amaitu da: Formula SAT da */
					return azpiformula.getLiteralenEsleipenak();
				}else if(!azpiformula.getKlausulaTxikiena().hutsaDa()){
					azpiformulak.add(azpiformula);
				}
			}
		}
		return null; /* Formula UNSAT da */
	}

	/**
	 * Formula bat emanda, formula beste azpiformuletan (sinpleagoetan) banatzen duen metodoa
	 */
	private LinkedList<CNFFormula> hedatu(CNFFormula formula){
		LinkedList<CNFFormula> azpiproblemaBerriak = new LinkedList<CNFFormula>();
		/* Unit propagation */
		propagazioUnitarioa(formula);
		/* Pure literal elimination */
		literalPuruenEzabapena(formula);
		if(!formula.hutsaDa() && !formula.getKlausulaTxikiena().hutsaDa()){
			/* Split: literal bat hartu eta TRUE FALSE balioak esleituz bi azpiformula berri lortu */
			KlausulaLiterala literala = formula.getKlausulaTxikiena().getLiteralBat();
			CNFFormula f1 = literalarenBalioaFormulanJarri(formula, literala);
			azpiproblemaBerriak.add(f1);
			KlausulaLiterala literalaEzeztua = new KlausulaLiterala(literala.getLiteralZenbakia(), !literala.getZeinua());
			CNFFormula f2 = literalarenBalioaFormulanJarri(formula, literalaEzeztua);
			azpiproblemaBerriak.add(f2);
		}else{
			azpiproblemaBerriak.add(formula);
		}
		return azpiproblemaBerriak;
	}
	
	/**
	 * Formula eta literal bat emanda, formula berri bat eraikitzen duen metodoa, literalak izan beharko lukeen balioa 
	 * kontuan hartuz 
	 * (zeinua true bada --> true)
	 * (zeinua false bada --> false)
	 */
	private CNFFormula literalarenBalioaFormulanJarri(CNFFormula formula, KlausulaLiterala literala) {
		CNFFormula formulaBerria = new CNFFormula();
		/* Aldagaiei esleitutako balioak kopiatu */
		formulaBerria.setLiteralenEsleipenak(new LinkedList<KlausulaLiterala>(formula.getLiteralenEsleipenak()));
		formulaBerria.getLiteralenEsleipenak().add(literala);
		/* Literalen agerpenak (baiezkoak eta ezezkoak) kopiatu */
		formulaBerria.setBaiLiteralKop(formula.getBaiLiteralKop().clone());
		formulaBerria.setEzLiteralKop(formula.getEzLiteralKop().clone());
		
		/* Formula berria eraiki */
		KlausulaLiterala literalaEzeztua = new KlausulaLiterala(literala.getLiteralZenbakia(), !literala.getZeinua());
		for(Klausula klausula : formula.getKlausulaZerrenda()){
			if(!klausula.klausulaLiteralaDago(literala)){
				Klausula klausulaBerria = klausula.kopia();
				if(klausula.klausulaLiteralaDago(literalaEzeztua)){
					klausulaBerria.klausulaLiteralaEzabatu(literalaEzeztua);
					literalarenAgerpenKopuruaEguneratu(formulaBerria, literalaEzeztua);
				}
				formulaBerria.klausulaBerriaGehitu(klausulaBerria);
				/* Formula berriko klausula txikiena harrapatzeko */
				if(formulaBerria.getKlausulaTxikiena()==null || formulaBerria.getKlausulaTxikiena().literalKopurua()>klausulaBerria.literalKopurua()){
					formulaBerria.setKlausulaTxikiena(klausulaBerria);
				}
			}else{
				literalenAgerpenakEguneratu(formulaBerria,klausula);
			}
		}
		return formulaBerria;
	}

	/**
	 * Propagazio unitarioa egiteaz arduratzen den metodoa
	 */
	private void propagazioUnitarioa(CNFFormula formula){
		Klausula klausulaTxikiena = klausulaUnitarioaDago(formula);
		while(klausulaTxikiena!=null){
			formula.setKlausulaTxikiena(null);
			/* Klausulan dagoen literal bakarra hartu */
			KlausulaLiterala literala = klausulaTxikiena.getLiteralBat();
			formula.getLiteralenEsleipenak().add(literala);
			KlausulaLiterala literalaEzeztua = new KlausulaLiterala(literala.getLiteralZenbakia(), !literala.getZeinua());
			Iterator<Klausula> iteradorea = formula.getKlausulaZerrenda().iterator();
			/* Formulako klausula guztiak korritu */
			while(iteradorea.hasNext()){
				Klausula klausula = iteradorea.next();							
				if(klausula.klausulaLiteralaDago(literala)){
					literalenAgerpenakEguneratu(formula, klausula);
					iteradorea.remove();
				}else{
					if(klausula.klausulaLiteralaDago(literalaEzeztua)){
						literalarenAgerpenKopuruaEguneratu(formula, literalaEzeztua);
						klausula.klausulaLiteralaEzabatu(literalaEzeztua);
					}
					/* Formulako klausula txikiena harrapatzeko */
					if(klausula!=klausulaTxikiena && (formula.getKlausulaTxikiena()==null || klausula.literalKopurua()<=formula.getKlausulaTxikiena().literalKopurua())){
						formula.setKlausulaTxikiena(klausula);
					}
				}
			}
			klausulaTxikiena = klausulaUnitarioaDago(formula);
		}
	}
	
	/**
	 * Klausula unitarioak dauden ala ez jakinarazten digun metodoa
	 */
	private Klausula klausulaUnitarioaDago(CNFFormula formula){
		Klausula klausulaTxikiena = formula.getKlausulaTxikiena();
		if(!formula.hutsaDa() && klausulaTxikiena.literalKopurua()==1){
			return klausulaTxikiena;
		}else{
			return null;
		}
	}
	
	/**
	 * Literal puruen ezabapenaz arduratzen den metodoa
	 */
	private void literalPuruenEzabapena(CNFFormula formula){
		HashSet<KlausulaLiterala> literalPuruak = literalPuruakDaude(formula);
		while(literalPuruak!=null){
			formula.setLiteralPuruak(new HashSet<KlausulaLiterala>());
			for(KlausulaLiterala literalPurua : literalPuruak){
				formula.getLiteralenEsleipenak().add(literalPurua);
				Iterator<Klausula> iteradorea = formula.getKlausulaZerrenda().iterator();
				while(iteradorea.hasNext()){
					Klausula klausula = iteradorea.next();
					if(klausula.klausulaLiteralaDago(literalPurua)){
						literalenAgerpenakEguneratu(formula, klausula);
						iteradorea.remove();
					}
				}
			}
			literalPuruak = literalPuruakDaude(formula);
		}
				
	}

	/**
	 * Literal puruak dauden ala ez jakinarazten digun metodoa
	 */
	private HashSet<KlausulaLiterala> literalPuruakDaude(CNFFormula formula) {
		if(formula.getLiteralPuruak().isEmpty() || formula.hutsaDa() || formula.getKlausulaTxikiena().hutsaDa()){
			return null;
		}else{
			return formula.getLiteralPuruak();
		}
	}

	/**
	 * Literal puruak aurkitzeko metodo laguntzailea.
	 * Klausula bat formulatik ezabatzen denean literalen agerpenak eguneratu behar dira.
	 */
	private void literalenAgerpenakEguneratu(CNFFormula formulaBerria, Klausula klausula) {
		for(KlausulaLiterala klausulaLiterala : klausula.getKlausularenLiteralZerrenda()){
			literalarenAgerpenKopuruaEguneratu(formulaBerria, klausulaLiterala);
		}
	}

	/**
	 * Literal puruak aurkitzeko metodo laguntzailea.
	 * Literal bat klausula batetik ezabatzen denean bere agerpenak eguneratu behar dira.
	 */
	private void literalarenAgerpenKopuruaEguneratu(CNFFormula formula, KlausulaLiterala literala) {
		int [] aux;
		int [] aux1;
		if(literala.getZeinua()){
			aux = formula.getBaiLiteralKop();
			aux1 = formula.getEzLiteralKop();
		}else{
			aux = formula.getEzLiteralKop();
			aux1 = formula.getBaiLiteralKop();
		}
		aux[literala.getLiteralZenbakia()-1]--;
		if(aux[literala.getLiteralZenbakia()-1]==0 && aux1[literala.getLiteralZenbakia()-1]!=0){
			KlausulaLiterala literalaEzeztua = new KlausulaLiterala(literala.getLiteralZenbakia(), !literala.getZeinua());
			formula.literalPuruaGehitu(literalaEzeztua);
		}else if(formula.getLiteralPuruak().contains(literala)){
			formula.getLiteralPuruak().remove(literala);
		}
	}

	/**
	 * Emaitza fitxategian idazteko metodoa
	 */
	private int emaitzaFitxategianIdatzi(String outFitxategiIzena, LinkedList<KlausulaLiterala> esleipenak){
		try {
		    File fitxategia =new File("Output/"+outFitxategiIzena);
		    BufferedWriter writer = new BufferedWriter(new FileWriter(fitxategia));
		    if(esleipenak!=null){
//		    	for(KlausulaLiterala literala: esleipenak){
//			    	if(literala.getZeinua()){
			    		writer.write(esleipenak.toString());
//			    	}
//			    }
		    }else{
		    	writer.write("BETEEZINA");
		    }
		    writer.write("\n");
		    writer.write(adabegiKop+"\n");
		    writer.close();
		    return 0;
		} catch(Exception e) {
			System.out.println("Arazoa egon da " + outFitxategiIzena + " fitxategia sortzerakoan");
			System.out.println(e.getMessage());
			return (-1);
		}
	}
}
